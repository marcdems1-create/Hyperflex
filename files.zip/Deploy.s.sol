// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Script.sol";
import "../src/MockUSDH.sol";
import "../src/MockHyperCoreOracle.sol";
import "../src/HyperFlexPriceAggregator.sol";
import "../src/HyperFlexFactory.sol";
import "../src/HyperFlexMarket.sol";
import "../src/HyperFlexRouter.sol";

/**
 * @title  Deploy
 * @notice Full testnet deployment — HyperEVM Testnet (Chain ID 998)
 *
 * Deploy order:
 *   1. MockUSDH          — testnet stablecoin with faucet
 *   2. MockHyperCoreOracle — primary price feed (precompile stand-in)
 *   3. HyperFlexPriceAggregator — dual-oracle confirmation layer
 *   4. HyperFlexFactory  — market deployer + bootstrap reserve
 *   5. HyperFlexRouter   — user entry point + referrals
 *   6. Seed 6 markets    — with correct March 2026 prices
 *
 * After deploy: start the price monitor bot
 *   node scripts/priceMonitor.js
 *
 * Run:
 *   forge script script/Deploy.s.sol \
 *     --rpc-url https://api.hyperliquid-testnet.xyz/evm \
 *     --private-key $PRIVATE_KEY \
 *     --broadcast \
 *     --legacy \
 *     -vvvv
 */
contract Deploy is Script {

    uint256 constant BOOTSTRAP_PER_SIDE = 100 * 1e6;
    uint256 constant BOOTSTRAP_RESERVE  = 5_000 * 1e6;
    uint256 constant CREATION_FEE       = 1 * 1e6;

    function run() external {
        uint256 pk       = vm.envUint("PRIVATE_KEY");
        address deployer = vm.addr(pk);

        vm.startBroadcast(pk);

        // ── 1. Mock USDH ──────────────────────────────────────────────
        MockUSDH usdh = new MockUSDH();
        console.log("MockUSDH:            ", address(usdh));

        // ── 2. Primary oracle (HyperCore precompile stand-in) ─────────
        MockHyperCoreOracle primaryOracle = new MockHyperCoreOracle();
        console.log("PrimaryOracle:       ", address(primaryOracle));

        // ── 3. Dual-oracle aggregator ─────────────────────────────────
        // Takes HyperCore price + secondary pushed by monitor bot.
        // Markets can only resolve when both sources agree within 1%.
        HyperFlexPriceAggregator aggregator = new HyperFlexPriceAggregator(
            address(primaryOracle)
        );
        console.log("PriceAggregator:     ", address(aggregator));

        // Register deployer as feeder (monitor bot will use a separate key)
        // aggregator.addFeeder(FEEDER_BOT_ADDRESS); // add your bot wallet here

        // ── 4. Factory ────────────────────────────────────────────────
        HyperFlexFactory factory = new HyperFlexFactory(
            address(usdh),
            address(primaryOracle),
            address(aggregator),
            deployer,           // feeRecipient
            CREATION_FEE,
            BOOTSTRAP_PER_SIDE
        );
        console.log("HyperFlexFactory:    ", address(factory));

        // ── 5. Router ─────────────────────────────────────────────────
        HyperFlexRouter router = new HyperFlexRouter(
            address(factory),
            address(usdh),
            deployer
        );
        console.log("HyperFlexRouter:     ", address(router));

        // ── 6. Fund bootstrap reserve ─────────────────────────────────
        usdh.approve(address(factory), BOOTSTRAP_RESERVE);
        factory.depositBootstrapReserve(BOOTSTRAP_RESERVE);
        console.log("Bootstrap reserve:    5,000 USDH");

        // ── 7. Seed markets — prices from scanner, March 2026 ─────────

        // XAG $83.48 → will it hit $90 before Jun 1?
        _createMarket(factory, usdh, MarketParams({
            question:    "Will XAG/USD hit $90/oz before June 1, 2026?",
            sector:      "COMMODITIES",
            iconEmoji:   unicode"🥈",
            closesAt:    1748736000,
            resolvesAt:  1748822400,
            resType:     ResolutionType.PRICE_ABOVE,
            assetIndex:  11,
            strikePrice: 90_000_000,      // $90.00
            resolver:    address(0),
            creatorFee:  50
        }));

        // XAU $5,171 → will it hit $5,800 before Jun 30?
        _createMarket(factory, usdh, MarketParams({
            question:    "Will XAU/USD hit $5,800/oz before June 30, 2026?",
            sector:      "COMMODITIES",
            iconEmoji:   unicode"🥇",
            closesAt:    1751241600,
            resolvesAt:  1751328000,
            resType:     ResolutionType.PRICE_ABOVE,
            assetIndex:  12,
            strikePrice: 5_800_000_000,   // $5,800.00
            resolver:    address(0),
            creatorFee:  50
        }));

        // WTI $89 → will it hit $100 by Q3?
        _createMarket(factory, usdh, MarketParams({
            question:    "Will WTI crude exceed $100/barrel by Q3 2026?",
            sector:      "COMMODITIES",
            iconEmoji:   unicode"🛢️",
            closesAt:    1759276800,
            resolvesAt:  1759363200,
            resType:     ResolutionType.PRICE_ABOVE,
            assetIndex:  13,
            strikePrice: 100_000_000,     // $100.00
            resolver:    address(0),
            creatorFee:  50
        }));

        // BTC ~$85K → will it hit $150K before end of 2026?
        _createMarket(factory, usdh, MarketParams({
            question:    "Will Bitcoin hit $150,000 before end of 2026?",
            sector:      "CRYPTO",
            iconEmoji:   unicode"₿",
            closesAt:    1767139200,
            resolvesAt:  1767225600,
            resType:     ResolutionType.PRICE_ABOVE,
            assetIndex:  0,
            strikePrice: 150_000_000_000, // $150,000.00
            resolver:    address(0),
            creatorFee:  50
        }));

        // HYPE ~$15 → will it hit $100 in 2026?
        _createMarket(factory, usdh, MarketParams({
            question:    "Will HYPE token exceed $100 in 2026?",
            sector:      "CRYPTO",
            iconEmoji:   unicode"💧",
            closesAt:    1767139200,
            resolvesAt:  1767225600,
            resType:     ResolutionType.PRICE_ABOVE,
            assetIndex:  10,
            strikePrice: 100_000_000,     // $100.00
            resolver:    address(0),
            creatorFee:  50
        }));

        // XAU → will it close above $6,000 in 2026?
        _createMarket(factory, usdh, MarketParams({
            question:    "Will gold close above $6,000/oz in 2026?",
            sector:      "COMMODITIES",
            iconEmoji:   unicode"🥇",
            closesAt:    1767139200,
            resolvesAt:  1767225600,
            resType:     ResolutionType.PRICE_ABOVE,
            assetIndex:  12,
            strikePrice: 6_000_000_000,   // $6,000.00
            resolver:    address(0),
            creatorFee:  50
        }));

        vm.stopBroadcast();

        // ── 8. Summary ────────────────────────────────────────────────
        console.log("\n=================================================");
        console.log("  HYPERFLEX TESTNET DEPLOYMENT COMPLETE");
        console.log("=================================================");
        console.log("Network:     HyperEVM Testnet (Chain ID 998)");
        console.log("Deployer:   ", deployer);
        console.log("");
        console.log("Paste into .env and hyperflex-v5-wired.html:");
        console.log("  USDH_ADDRESS=      ", address(usdh));
        console.log("  AGGREGATOR_ADDRESS=", address(aggregator));
        console.log("  FACTORY_ADDRESS=   ", address(factory));
        console.log("  ROUTER_ADDRESS=    ", address(router));
        console.log("");
        console.log("NEXT: start the price monitor bot:");
        console.log("  AGGREGATOR_ADDRESS=<above> node scripts/priceMonitor.js");
        console.log("");
        console.log("The monitor MUST be running before any market can resolve.");
        console.log("=================================================\n");
    }

    function _createMarket(
        HyperFlexFactory factory,
        MockUSDH usdh,
        MarketParams memory p
    ) internal {
        usdh.approve(address(factory), CREATION_FEE);
        (, address market) = factory.createMarket(p);
        console.log("Market:", p.question);
        console.log("  addr:", market);
    }
}
